OTF and TTF: Caf� Fran�oise 
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

*****WARNING: Due to complex detail it is not adisable to preview in Windows font viewer. PC slowdown may occur.*****

Bonjour font fans. Bienvenue au Caf� Fran�oise! (pronounced frahn-SWOSS). This simple and charming display font was inspired by outdoor chalk boards that showcase an outdoor cafe's specials. I encountered these in places like Paris, London, NY, Montreal, and all over Belgium. It's casual
 nature lends to a relaxation synonomous with lingering over an espresso.The glyphs are irregular and slightly eroded for a handwritten l look. Basic latin, extended latin, diacritics and punctuation are included. You can pair pictured graphics if your application supports OTF features. Kerning is 
added as well. Use it for a company logo, menu, or poster. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: stylish, vertical, display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, branding, sans, serif, casual, cafe, restaurant, menu, chalk, narrow, tall, high, poster, headline, relaxed, eroded, distorted, handwriting, town, square, outdoor, culture, London, Paris, 
New York, Quebec, France, England, Belgium, Montreal, French, Italian, Italy, Rome, food, wine, Europe, breakfast, croissants
