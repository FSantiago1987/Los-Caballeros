﻿var list = document.getElementById("topnav");
var a = document.createElement("a");
var link = document.createTextNode("Location");
a.appendChild(link);
list.appendChild(a);
a.href = "http://alorestaurant.com/";
a.className = "h";